# John Richard L. Binero — Portfolio

A responsive personal portfolio website for a Computer Engineering graduate.

## Included
- Modern dark technology design
- Responsive desktop/mobile layout
- Profile photo asset
- About, Skills, Experience, Projects and Contact sections
- Smooth scrolling and reveal animations
- Easy-to-edit placeholders for contact details

## Run locally
Open `index.html` in a browser.

## Replace content
- Profile photo: `assets/profile.jpg`
- Contact placeholders: edit the Contact section in `index.html`
- Project details: edit the Projects section in `index.html`
